package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.TraineeRepository;

import com.demo.model.Trainee;


@Service
public class TraineeService {
	 @Autowired
	public TraineeRepository traineeRepository;
	
	//create or save a new trainee
	    public Trainee CreateTrainee(Trainee trainee) {
	    	
		return traineeRepository.save(trainee );
		
	    }
	
	    // Retrieve all trainees
	    public List<Trainee> getAllTrainees() {
	        return traineeRepository.findAll();
	    }

	    // Get a trainee by ID
	    public Trainee getTraineeById(Long id) {
	    	
	        return traineeRepository.findById(id)
	        		  .orElseThrow(() -> new RuntimeException("Trainee not found with id: " + id));
	    }

	    // Update an existing trainee
	    public Trainee updateTrainee(Long id, Trainee traineeDetails) {
	        Trainee trainee = traineeRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Trainee not found with id: " + id));
	        trainee.setFirstName(traineeDetails.getFirstName());
	        trainee.setLastName(traineeDetails.getLastName());
	        trainee.setEmail(traineeDetails.getEmail());
	        trainee.setGender(traineeDetails.getGender());
	        trainee.setPhonenum(traineeDetails.getPhonenum());
	        return traineeRepository.save(trainee);
	    }

	    // Delete a trainee by ID
	    public String deleteTrainee(Long id) {
	    	 Trainee trainee= traineeRepository.findById(id)
	    			 .orElseThrow(() -> new RuntimeException("Trainee not found with id: " + id));
	     traineeRepository.delete(trainee);
	       return "trainee deleted successfully";
	    }
}
