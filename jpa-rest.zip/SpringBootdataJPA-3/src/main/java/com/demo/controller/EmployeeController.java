package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/emp")
@Validated
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@PostMapping("/add")//http:localhost:5483/emp/add
	public ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee emp)
	{ Employee addemp=service.addEmployee(emp);
		return new ResponseEntity<Employee>(addemp, HttpStatus.CREATED);
		
	}
	@PutMapping("/update") //http://localhost:5483/emp/update
	public ResponseEntity<Employee> updateEmployee(@Valid @RequestBody Employee emp)
	{Employee updateEmp=service.updateEmployee(emp);
		return new ResponseEntity<Employee>(updateEmp,HttpStatus.CREATED) ;
	}
	@GetMapping("/get/{id}")//http://localhost:5483/emp/get/id
	public ResponseEntity<Employee> getEmployee(@PathVariable("id") int empid) {
		Employee getEmp=service.getEmployeebyId(empid);
		return new ResponseEntity<Employee>(getEmp,HttpStatus.OK);
	}
	@GetMapping("/getall")
	public ResponseEntity<List<Employee>> getAllEmployee() 
	{
		List<Employee>getAll=service.getAllEmployees();
		return new ResponseEntity<List<Employee>>(getAll,HttpStatus.OK);
		
	}
	@DeleteMapping("/del/{id}")//http://localhost:5483/emp/del/id
	public ResponseEntity<String>  deleteEmployee(@PathVariable("id") int empid) {
		String delEmp=service.deleteEmployeeById(empid);
		return new ResponseEntity<String>(delEmp,HttpStatus.OK);
		
	}
}
