package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Account;
import com.demo.service.AccountService;

@RestController
@RequestMapping("api/accounts")
@CrossOrigin("*")
public class AccountController {

	@Autowired
	private AccountService accountservice;
		
	@GetMapping("/getall")//http://localhost:1111/accounts/getall
	public List<Account>getAllAccounts(){
		return accountservice.getAllAccounts();
	}
	@GetMapping("/get{id}")//local:1111/accounts/get/id
	public Account getAccountById(Long Id) {
		return accountservice.getAccountById(Id);
	}
	@PostMapping("/create")//http://localhost:1111/api/accounts/create
	public ResponseEntity<Account>createAccount(@RequestBody Account account, @RequestBody Account accountDetails) {
		Account create=accountservice.createAccount(accountDetails);
		return new ResponseEntity<Account>(create,HttpStatus.CREATED);
		
	
//	public ResponseEntity<String> createAccount(@RequestBody Map<String, Object>request) {
//		String accountnumber=(String)request.get("accountnumber");
//		double balance=(double)request.get("balance");
//		Long customerId=(Long)request.get("customerId");
//		return accountservice.createAccount(accountnumber,balance,customerId);
		
	}
	
	
//	@PutMapping("/{id}") 
//	public ResponseEntity<Account> updateAccount(@PathVariable Long id, @RequestBody Account accountDetails) 
//	{ Account updatedAccount = accountService.updateAccount(id, accountDetails);
//	return ResponseEntity.ok(updatedAccount); }
//	@DeleteMapping("/{id}")
//	public ResponseEntity<Void> deleteAccount(@PathVariable Long id) 
//	{ accountService.deleteAccount(id); 
//	return ResponseEntity.noContent().build(); }
	
	@PutMapping("/update{id}")//http://localhost:1111/api/accounts/update/id
	public ResponseEntity<Account> updateAccount(@PathVariable Long AccountId,@RequestBody Account accountDetails) {
		Account updateaccount=accountservice.updateAccount( AccountId,accountDetails);
		return new ResponseEntity<Account>(updateaccount,HttpStatus.CREATED);
		
	}
	@DeleteMapping("/delete{id}")//http://localhost:1111/api/accounts/delete/id
	public ResponseEntity<String> deleteAccount(@PathVariable Long AccountId){
		String delete =accountservice.deleteAccount(AccountId);
		return new ResponseEntity<String>(delete,HttpStatus.OK) ; 
	}
	@GetMapping("/gettransfer")//http://localhost:1111/api/accounts/gettransfer
	public ResponseEntity<String> transferFunds(Long fromAccountId, Long toAccountId, double amount) {
		String transFunds =accountservice.transferFunds( fromAccountId,  toAccountId, amount);
		return new ResponseEntity<String>(transFunds,HttpStatus.OK);
		
	}
	@GetMapping("/getaccount/{customerId}")       //http://localhost:1111/api/accounts/getaccount/id
	public  List<Account> getAccountsByCustomer(@PathVariable Long customerId){
		return accountservice.getAccountsByCustomer(customerId);
	}

}
