package com.demo.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.EmployeeDao;
import com.demo.exceptions.EmployeeNotFoundException;
import com.demo.model.Employee;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao dao;
	
	@Override
	public Employee addEmployee(Employee emp) {
	
		return dao.save(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		if(!dao.existsById(emp.getEmpid()))
		{
			throw new EmployeeNotFoundException("Employee :"+emp.getEmpid()+"not found");
		}
		

		return dao.save(emp);
	}

	@Override
	public Employee getEmployeebyId(int empid) {
		 Optional<Employee> emp=dao.findById(empid);
			Employee getemp=emp.get();
			if(emp.isEmpty()){
				throw new EmployeeNotFoundException("Employee"+empid+"not found");
			}
			return getemp;
	}

	@Override
	public String deleteEmployeeById(int empid) {
		
		 if(!dao.existsById(empid)) {
			 throw new EmployeeNotFoundException("EmployeeNotFound"+empid);
		 }
		 dao.deleteById(empid);
		return "deleted successfully";
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return dao.findAll();
	}

	

}
