package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Exception.ResourceNotFoundException;
import com.demo.dao.AccountRepository;
import com.demo.dao.CustomerRepository;
import com.demo.model.Account;
//import com.demo.model.Customer;
import com.demo.model.Customer;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class AccountService {
	
	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private CustomerRepository customerRepository;
	
	
	public List<Account>getAllAccounts(){
		return accountRepository.findAll();
		
	}
	public Account getAccountById(Long accountId) {
		return accountRepository.findById(accountId)
				                .orElseThrow(()->new ResourceNotFoundException("account not found"));
		
	}

	public Account createAccount(Account account) {
//	public Account createAccount(String accountnumber,double balance,Long customer) {
//		Customer Customer=customerRepository.findById(Id)
//				.orElseThrow(()->new ResourceNotFoundException("Customer not found with ID:"+customerId));
//		Account account=new Account();
//		account.setAccountNumber(accountnumber);
//		account.setBalance(balance);
//		account.setCustomer(customer);
		return accountRepository.save(account);
	}

	public Account updateAccount(Long accountId, Account accountDetails) {
		Account account=accountRepository.findById(accountId)
				                         .orElseThrow(()->new ResourceNotFoundException("account is not found)"));
		account.setAccountNumber(accountDetails.getAccountNumber());
		account.setBalance(accountDetails.getBalance());
		
		return accountRepository.save(account);
	}

	public String deleteAccount(Long accountId) {
		Account account=accountRepository.findById(accountId)
				                         .orElseThrow(()->new ResourceNotFoundException("account not found"));
		
			accountRepository.delete(account);
		
		return "deleted successfully";
		
		
	}
	public String transferFunds(Long fromAccountId, Long toAccountId, double amount) {
	Account	fromAccount=accountRepository.findById(fromAccountId)
			.orElseThrow(()->new ResourceNotFoundException("account not found"));
	Account toAccount=accountRepository.findById(toAccountId)
			.orElseThrow(()->new ResourceNotFoundException("account not found"));
	if(fromAccount.getBalance()<amount) {
		throw new ResourceNotFoundException("insuffiecient balance");
	}
	fromAccount.setBalance(fromAccount.getBalance()-amount);
	toAccount.setBalance(toAccount.getBalance()+amount);
	
	accountRepository.save(fromAccount);
	accountRepository.save(toAccount);
	return "funds transfered";
		
	}
//	 transferFunds(Long fromAccountId, Long toAccountId, double amount): 
//	Transfer funds between accounts. 

	public List<Account>getAccountsByCustomer(Long customerId){
		Customer customer=customerRepository.findById(customerId)
				.orElseThrow(()->new ResourceNotFoundException("customer account not found"));;
		return customer.getAccount();
		
	}
	//	 getAccountsByCustomer(Long customerId): Retrieve all accounts 
//	belonging to a specific customer.
}
