package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Exception.ResourceNotFoundException;
import com.demo.dao.CustomerRepository;
import com.demo.model.Customer;
@Service
public class CustomerService {

	@Autowired
	public CustomerRepository customerRepository;
	
	public List<Customer>  getAllCustomers() {
		return customerRepository.findAll();
		
	}
	public Customer getCustomerById(Long CustomerId) {
		return customerRepository.findById(CustomerId)
				.orElseThrow(()->new ResourceNotFoundException("customerId not found:"+CustomerId));
		
	}
	public Customer createCustomer(Customer customer) {
		
		return customerRepository.save(customer);
		
	}
	public Customer updateCustomer(Long CustomerId,Customer customerDetails) {
		Customer customer=customerRepository.findById(CustomerId)
				.orElseThrow(()->new ResourceNotFoundException("customerId not found:"+CustomerId));
		customer.setName(customerDetails.getName());
		customer.setAddress(customerDetails.getAddress());
		
		return customerRepository.save(customer);
		
	}
	public String deleteCustomer(Long CustomerId) {
		Customer customer=customerRepository.findById(CustomerId)
				.orElseThrow(()->new ResourceNotFoundException("customerId not found:"+CustomerId));
		
		customerRepository.delete(customer);
		return "customerId deleted successfully";
		
		
	}
//	public Customer getCustomerByEmail(String email) {
//		
//		return customerRepository.findByEmail(email)
//				.orElseThrow(()->new ResourceNotFoundException("customerId not found"));;
//		
//	}
//	public Customer getCustomerAccountsSummary(Long customerId) {
//		Customer customer=customerRepository.findById(customerId)
//				.orElseThrow(()->new ResourceNotFoundException("customerId not found"));
//		List<Account> accounts=customer.getAccounts();
//		double TotalBalance=accounts.stream().mapToDouble(Account::getBalance).sum();
//		return new CustomerAccountsSummary(customerId, totalBalance, accounts);
//		
//	}
}
