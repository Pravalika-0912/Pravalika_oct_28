package com.demo.model;

import java.util.ArrayList;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter 
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Customer {
@Id
@GeneratedValue
	private Long id;
	private String name;
    private String address;
	private String email;
	@OneToMany(mappedBy ="customer",cascade = CascadeType.ALL)
	private List<Account> account=new ArrayList<>();
}
