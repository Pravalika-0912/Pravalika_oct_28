package com.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="emprest")

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Employee {
	

	@Id
	private int empid;
    @NotBlank(message="employee cannot be blank")
	private String empname;
    @Min(value=0,message="salary cannot be nill")
	private int empsal;
    @NotBlank(message="address cannot be blank")
	private String empadd;
	
}
