//package com.demo.dao;
//
//import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.demo.model.Employee;
//
//import jakarta.persistence.EntityManager;
//import jakarta.persistence.PersistenceContext;
//import jakarta.persistence.TypedQuery;
//@Repository
//public class EmployeeDaoImpl implements EmployeeDao {
//
//	@PersistenceContext
//	private EntityManager entity;
//	@Override
//	public Employee addEmployee(Employee emp) {
//		entity.persist(emp);
//		return entity.find(Employee.class,emp.getEmpid());
//	}
//
//	@Override
//	public Employee updateEmployee(Employee emp) {
//		
//		return entity.merge(emp);
//	}
//
//	@Override
//	public Employee getEmployeebyId(int empid) {
//		Employee empr=entity.find(Employee.class, empid);
//		return empr;
//	}
//
//	@Override
//	public String deleteEmployeeById(int empid) {
//		Employee empd=entity.find(Employee.class, empid);
//		if(empd!=null) {
//			entity.remove(empd);
//			return "employee deleted successfully";
//		}
//		else {
//			return "employee not found";
//		}
//		
//	}
//
//	@Override
//	public List<Employee> getAllEmployees() {
//		TypedQuery<Employee> tq=entity.createQuery("select e from Employee e",Employee.class);
//		return tq.getResultList();
//	}
//
//}
