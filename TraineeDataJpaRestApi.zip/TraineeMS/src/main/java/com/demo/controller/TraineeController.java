package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Trainee;
import com.demo.service.TraineeService;

@RestController
@RequestMapping("/TMS")
public class TraineeController {

	@Autowired
    private TraineeService traineeService;
	
	//handler methods
	 @PostMapping("/add")//http://localhost:1116/TMS/add
	    public Trainee CreateTrainee(@RequestBody Trainee trainee ) {
	        return  traineeService.CreateTrainee(trainee);
	    }
	
	 //update
	 @PutMapping("/update")//http://localhost:1116/TMS/update
	 public Trainee updateTrainee(@RequestBody 
			 Long Id,Trainee traineeDetails) {
		return traineeService.updateTrainee(Id, traineeDetails);
		 
	 }
	 //delete
	 @DeleteMapping("/del")//http://localhost:1116/TMS/del
	 public String deleteTrainee(@PathVariable Long Id) {
		
				traineeService.deleteTrainee(Id);
				return "trainee deleted successfully";
		 
	 }
	 //getTraineeById
	 @GetMapping("/get/{id}")//http://localhost:1116/TMS/get/id
	 public Trainee getTraineeById(@PathVariable Long Id) {
		return traineeService.getTraineeById(Id);
		 
	 }
	 //getall
	 @GetMapping("/getall")//http://localhost:1116/TMS/getall
	 public List<Trainee> getAllTrainees(){
		return traineeService.getAllTrainees();
		 
	 }
}
